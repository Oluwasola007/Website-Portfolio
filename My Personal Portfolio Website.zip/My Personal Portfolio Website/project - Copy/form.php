<?php
if (isset($_POST['submit'];)) {
    $name = $_POST['name'];
    $mailFrom = $_POST['email'];
    $phoneNumber = $_POST['phone'];
    $message = $_POST['message'];

    $to = "oluwasolaoluwatosin@gmail.com";
    
    $subject = "A New Message from codewithsola.com";
    $txt = "Name = ". $name . "\r\n Email = ". $mailFrom . "\r\n Phone = ". $phoneNumber . "\r\n Message = "$message;"
    $headers = "From: oluwasola@codewithsola.com" . "\r\n" . 
    if($mailFrom! = NULL){
        mail($to, $subject, $txt, $headers);
}

?>



